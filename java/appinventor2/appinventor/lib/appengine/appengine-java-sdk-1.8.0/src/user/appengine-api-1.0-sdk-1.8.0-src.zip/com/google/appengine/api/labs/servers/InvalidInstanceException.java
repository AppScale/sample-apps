package com.google.appengine.api.labs.servers;

/**
 * Exception thrown when the given instance value is not valid.
 *
 */
public class InvalidInstanceException extends ServersException {

  InvalidInstanceException(String detail) {
    super(detail);
  }
}
